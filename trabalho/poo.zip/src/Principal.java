
public class Principal {

    public static void main(String[] args) {
        // Criando objetos Pessoa 
        Pessoa[] pessoas = {
            new Pessoa(1, "Joao", 25, 2500.00, "Analista"),
            new Pessoa(2, "Maria", 30, 3000.00, "Estoquista"),
            new Pessoa(3, "Carlos", 35, 4000.00, "Financeiro")
        };

        // Exibir os dados (método de cada objeto) 
        System.out.println("=== DADOS PESSOAIS ===");
        for (Pessoa p : pessoas) {
            p.exibirDados();
        }

        // Estatísticas simples 
        double somaSalarios = 0;
        int somaIdades = 0;
        for (Pessoa p : pessoas) {
            somaSalarios += p.getSalario();
            somaIdades += p.getIdade();
        }

        System.out.println("\nMédia de Idade: " + (somaIdades / pessoas.length));
        System.out.println("Média Salarial: R$ " + (somaSalarios / pessoas.length));
    }
}
