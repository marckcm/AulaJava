
public class Pessoa {

    private int id;
    private String nome;
    private int idade;
    private double salario;
    private String cargo;

    // Construtor 
    public Pessoa(int id, String nome, int idade, double salario, String cargo) {
        this.id = id;
        this.nome = nome;
        this.idade = idade;
        this.salario = salario;
        this.cargo = cargo;
    }

    // Métodos Getters 
    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public double getSalario() {
        return salario;
    }
    public String getCargo() {
        return cargo;
    }

    // Método para exibir dados 
    public void exibirDados() {
        System.out.println("ID: " + id + ", Nome: " + nome + ", Idade: " + idade + ", Salário: R$"
                + salario + ", Cargo: " + cargo);
    }
}
