
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * @author Marcelo de Castro Moreira
 */
public class TelaPrincipal extends javax.swing.JFrame {

    /**
     * Criando novo formulario TelaPrincipal
     */
    public TelaPrincipal() {
        initComponents();
        atualizarTabela();
    }

    private void atualizarTabela() {
        DefaultTableModel model = (DefaultTableModel) tabelaPessoas.getModel();
        model.setRowCount(0); // Limpa a tabela 

        List<Pessoa> pessoas = PessoaDAO.listar();
        for (Pessoa p : pessoas) {
            model.addRow(new Object[]{
                p.getId(),
                p.getNome(),
                p.getIdade(),
                p.getSalario()
            });
        }
    }

    private double calcularMedia(double[] valores) {
        double soma = 0;
        for (double valor : valores) {
            soma += valor;
        }
        return soma / valores.length;
    }

    private int calcularMedia(int[] valores) {
        int soma = 0;
        for (int valor : valores) {
            soma += valor;
        }
        return soma / valores.length;
    }

    private double encontrarMaior(double[] valores) {
        double maior = valores[0];
        for (double valor : valores) {
            if (valor > maior) {
                maior = valor;
            }
        }
        return maior;
    }

    private void exibirRelatorio(Object[][] dados) {
        JFrame frameRelatorio = new JFrame("Relatório Completo");
        JTable tabelaRelatorio = new JTable(dados, new String[]{"", "", "", ""});
// Desabilita edição
        tabelaRelatorio.setDefaultEditor(Object.class, null);
// Rolagem
        JScrollPane scrollPane = new JScrollPane(tabelaRelatorio);
        frameRelatorio.add(scrollPane);
        frameRelatorio.setSize(600, 400);
        frameRelatorio.setLocationRelativeTo(null);
        frameRelatorio.setVisible(true);
    }

    /**
     * Este método é chamado de dentro do construtor para inicializar o
     * formulário. AVISO: NÃO modifique este código. O conteúdo deste método é
     * sempre regenerado pelo Editor de Formulários.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNome = new javax.swing.JTextField();
        txtIdade = new javax.swing.JTextField();
        txtSalario = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnInserir = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaPessoas = new javax.swing.JTable();
        btnRelatorio = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel5 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuEditar = new javax.swing.JMenu();
        menuInserir = new javax.swing.JMenuItem();
        menuAtualizar = new javax.swing.JMenuItem();
        menuExcluir = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        menuSair = new javax.swing.JMenuItem();
        menuDados = new javax.swing.JMenu();
        menuRelatorio = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Formulário Principal");
        setBackground(new java.awt.Color(255, 255, 255));
        setForeground(java.awt.Color.lightGray);

        txtNome.setToolTipText("");

        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Nome:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Idade:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Salário:");

        btnInserir.setBackground(new java.awt.Color(153, 204, 255));
        btnInserir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        btnInserir.setText("Inserir");
        btnInserir.setMaximumSize(new java.awt.Dimension(578, 519));
        btnInserir.setMinimumSize(new java.awt.Dimension(578, 519));
        btnInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInserirActionPerformed(evt);
            }
        });

        btnAtualizar.setBackground(new java.awt.Color(153, 204, 255));
        btnAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/atualizar.png"))); // NOI18N
        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtualizarActionPerformed(evt);
            }
        });

        btnExcluir.setBackground(new java.awt.Color(153, 204, 255));
        btnExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirActionPerformed(evt);
            }
        });

        tabelaPessoas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Idade", "Salário"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabelaPessoas.setName(""); // NOI18N
        tabelaPessoas.setShowGrid(true);
        jScrollPane1.setViewportView(tabelaPessoas);

        btnRelatorio.setBackground(new java.awt.Color(153, 204, 255));
        btnRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/relatorio.png"))); // NOI18N
        btnRelatorio.setText("Relatórios");
        btnRelatorio.setActionCommand("Relatorio");
        btnRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRelatorioActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        jLabel4.setText("Cadastro de Funcionário");

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel5.setText("Listagem de Funcionários Cadastrados");

        menuEditar.setText("Editar");

        menuInserir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuInserir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        menuInserir.setText("Inserir");
        menuInserir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuInserirActionPerformed(evt);
            }
        });
        menuEditar.add(menuInserir);

        menuAtualizar.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuAtualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/atualizar.png"))); // NOI18N
        menuAtualizar.setText("Atualizar");
        menuAtualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuAtualizarActionPerformed(evt);
            }
        });
        menuEditar.add(menuAtualizar);

        menuExcluir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/delete.png"))); // NOI18N
        menuExcluir.setText("Excluir");
        menuExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuExcluirActionPerformed(evt);
            }
        });
        menuEditar.add(menuExcluir);
        menuEditar.add(jSeparator3);

        menuSair.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/logout.png"))); // NOI18N
        menuSair.setText("Sair");
        menuSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuSairActionPerformed(evt);
            }
        });
        menuEditar.add(menuSair);

        jMenuBar1.add(menuEditar);

        menuDados.setText("Relatório");

        menuRelatorio.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menuRelatorio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/relatorio.png"))); // NOI18N
        menuRelatorio.setText("Relatório");
        menuRelatorio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRelatorioActionPerformed(evt);
            }
        });
        menuDados.add(menuRelatorio);

        jMenuBar1.add(menuDados);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(210, 210, 210))
            .addComponent(jSeparator2)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(jLabel5)))
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnInserir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSalario, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAtualizar)
                        .addGap(50, 50, 50)
                        .addComponent(btnExcluir)
                        .addGap(50, 50, 50)
                        .addComponent(btnRelatorio)))
                .addGap(55, 55, 55))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtIdade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtSalario))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnInserir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir)
                    .addComponent(btnRelatorio)
                    .addComponent(btnAtualizar))
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
        // TODO adicione seu código de manuseio aqui:
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void btnInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInserirActionPerformed
        String nome = txtNome.getText();
        int idade = Integer.parseInt(txtIdade.getText());
        double salario = Double.parseDouble(txtSalario.getText());

        PessoaDAO.inserir(new Pessoa(0, nome, idade, salario));
        atualizarTabela();
        limparCampos();
    }//GEN-LAST:event_btnInserirActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        int linha = tabelaPessoas.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma pessoa!");
            return;
        }

        int id = (int) tabelaPessoas.getValueAt(linha, 0);
        String nome = txtNome.getText();
        int idade = Integer.parseInt(txtIdade.getText());
        double salario = Double.parseDouble(txtSalario.getText());

        PessoaDAO.atualizar(new Pessoa(id, nome, idade, salario));
        atualizarTabela();
        limparCampos();
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int linha = tabelaPessoas.getSelectedRow();
        if (linha >= 0) {
            int id = (int) tabelaPessoas.getValueAt(linha, 0);
            PessoaDAO.excluir(id);
            atualizarTabela();
        }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
        List<Pessoa> pessoas = PessoaDAO.listar();
        if (pessoas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nenhum dado para gerar relatório!");
            return;
        }
// 1. USO DE VETORES para cálculos estatísticos
        double[] salarios = new double[pessoas.size()];
        int[] idades = new int[pessoas.size()];
        for (int i = 0; i < pessoas.size(); i++) {
            salarios[i] = pessoas.get(i).getSalario();
            idades[i] = pessoas.get(i).getIdade();
        }
// Cálculos estatísticos
        double mediaSalarial = calcularMedia(salarios);
        double maiorSalario = encontrarMaior(salarios);
        int mediaIdade = calcularMedia(idades);
// 2. USO DE MATRIZ para relatório completo
// Calcula o tamanho necessário: 5 linhas de cabeçalho + 1 linha de separação + N linhas de dados
        int totalLinhas = 6 + 1 + pessoas.size();
        Object[][] dadosRelatorio = new Object[totalLinhas][4];
// Cabeçalho
        dadosRelatorio[0][0] = "                 RELATÓRIO DE PESSOAS";
        dadosRelatorio[1][0] = "Total de registros: " + pessoas.size();
        dadosRelatorio[2][0] = "Média salarial: " + String.format("R$ %.2f", mediaSalarial);
        dadosRelatorio[2][1] = "Maior salário: " + String.format("R$ %.2f", maiorSalario);
        dadosRelatorio[3][0] = "Média de idade: " + mediaIdade + " anos";// Linha em branco para separar (linha 4)
        dadosRelatorio[4][0] = "";
        dadosRelatorio[5][0] = "DETALHES:";
// Cabeçalho da tabela (linha 5)
        dadosRelatorio[6][0] = "ID";
        dadosRelatorio[6][1] = "Nome";
        dadosRelatorio[6][2] = "Idade";
        dadosRelatorio[6][3] = "Salário";
// Dados das pessoas (começando da linha 6)
        for (int i = 0; i < pessoas.size(); i++) {
            Pessoa p = pessoas.get(i);
            dadosRelatorio[i + 7][0] = p.getId();
            dadosRelatorio[i + 7][1] = p.getNome();
            dadosRelatorio[i + 7][2] = p.getIdade();
            dadosRelatorio[i + 7][3] = p.getSalario();
        }
// Exibir relatório em uma nova janela
        exibirRelatorio(dadosRelatorio);
    }//GEN-LAST:event_btnRelatorioActionPerformed

    private void menuInserirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuInserirActionPerformed
        // TODO add your handling code here:
        String nome = txtNome.getText();
        int idade = Integer.parseInt(txtIdade.getText());
        double salario = Double.parseDouble(txtSalario.getText());

        PessoaDAO.inserir(new Pessoa(0, nome, idade, salario));
        atualizarTabela();
        limparCampos();
    }//GEN-LAST:event_menuInserirActionPerformed

    private void menuAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuAtualizarActionPerformed
        // TODO add your handling code here:
        int linha = tabelaPessoas.getSelectedRow();
        if (linha == -1) {
            JOptionPane.showMessageDialog(this, "Selecione uma pessoa!");
            return;
        }

        int id = (int) tabelaPessoas.getValueAt(linha, 0);
        String nome = txtNome.getText();
        int idade = Integer.parseInt(txtIdade.getText());
        double salario = Double.parseDouble(txtSalario.getText());

        PessoaDAO.atualizar(new Pessoa(id, nome, idade, salario));
        atualizarTabela();
        limparCampos();
    }//GEN-LAST:event_menuAtualizarActionPerformed

    private void menuExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuExcluirActionPerformed
        // TODO add your handling code here:
        int linha = tabelaPessoas.getSelectedRow();
        if (linha >= 0) {
            int id = (int) tabelaPessoas.getValueAt(linha, 0);
            PessoaDAO.excluir(id);
            atualizarTabela();
        }
    }//GEN-LAST:event_menuExcluirActionPerformed

    private void menuSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSairActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_menuSairActionPerformed

    private void menuRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelatorioActionPerformed
        // TODO add your handling code here:
                List<Pessoa> pessoas = PessoaDAO.listar();
        if (pessoas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nenhum dado para gerar relatório!");
            return;
        }
// 1. USO DE VETORES para cálculos estatísticos
        double[] salarios = new double[pessoas.size()];
        int[] idades = new int[pessoas.size()];
        for (int i = 0; i < pessoas.size(); i++) {
            salarios[i] = pessoas.get(i).getSalario();
            idades[i] = pessoas.get(i).getIdade();
        }
// Cálculos estatísticos
        double mediaSalarial = calcularMedia(salarios);
        double maiorSalario = encontrarMaior(salarios);
        int mediaIdade = calcularMedia(idades);
// 2. USO DE MATRIZ para relatório completo
// Calcula o tamanho necessário: 5 linhas de cabeçalho + 1 linha de separação + N linhas de dados
        int totalLinhas = 6 + 1 + pessoas.size();
        Object[][] dadosRelatorio = new Object[totalLinhas][4];
// Cabeçalho
        dadosRelatorio[0][0] = "                 RELATÓRIO DE PESSOAS";
        dadosRelatorio[1][0] = "Total de registros: " + pessoas.size();
        dadosRelatorio[2][0] = "Média salarial: " + String.format("R$ %.2f", mediaSalarial);
        dadosRelatorio[2][1] = "Maior salário: " + String.format("R$ %.2f", maiorSalario);
        dadosRelatorio[3][0] = "Média de idade: " + mediaIdade + " anos";// Linha em branco para separar (linha 4)
        dadosRelatorio[4][0] = "";
        dadosRelatorio[5][0] = "DETALHES:";
// Cabeçalho da tabela (linha 5)
        dadosRelatorio[6][0] = "ID";
        dadosRelatorio[6][1] = "Nome";
        dadosRelatorio[6][2] = "Idade";
        dadosRelatorio[6][3] = "Salário";
// Dados das pessoas (começando da linha 6)
        for (int i = 0; i < pessoas.size(); i++) {
            Pessoa p = pessoas.get(i);
            dadosRelatorio[i + 7][0] = p.getId();
            dadosRelatorio[i + 7][1] = p.getNome();
            dadosRelatorio[i + 7][2] = p.getIdade();
            dadosRelatorio[i + 7][3] = p.getSalario();
        }
// Exibir relatório em uma nova janela
        exibirRelatorio(dadosRelatorio);
    }//GEN-LAST:event_menuRelatorioActionPerformed

    private void limparCampos() {
        txtNome.setText("");
        txtIdade.setText("");
        txtSalario.setText("");
    }
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnInserir;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JMenuItem menuAtualizar;
    private javax.swing.JMenu menuDados;
    private javax.swing.JMenu menuEditar;
    private javax.swing.JMenuItem menuExcluir;
    private javax.swing.JMenuItem menuInserir;
    private javax.swing.JMenuItem menuRelatorio;
    private javax.swing.JMenuItem menuSair;
    private javax.swing.JTable tabelaPessoas;
    private javax.swing.JTextField txtIdade;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtSalario;
    // End of variables declaration//GEN-END:variables
}
